<div id="wait">
	<img src='/public/image/ajax-loader.gif' width="20px" height="20px"/>
</div>
<footer>
    <div class="container-fluid">
        <!-- &copy; Sentranetcomindo@2017 -->
        <span class="text-right" style="float:right;"><span class="glyphicon glyphicon-menu-left"></span>/<span class="glyphicon glyphicon-menu-right"></span> with <span class="glyphicon glyphicon-heart" style="color:red"></span> by A</span>
    </div>
</footer>
<script src="/public/vendor/trumbowyg/dist/trumbowyg.min.js"></script>
<script type="text/javascript" src="/public/custom/js/app.js"></script>
</body>
</html>